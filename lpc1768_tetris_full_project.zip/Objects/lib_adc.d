./objects/lib_adc.o: Source\ADC\lib_adc.c \
  C:\Users\Milad\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.2\Device\Include\LPC17xx.h \
  Source\CMSIS_core\core_cm3.h \
  C:\Users\Milad\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.2\Device\Include\system_LPC17xx.h \
  Source\ADC\adc.h
