./objects/system_lpc17xx_1.o: RTE\Device\LPC1768\system_LPC17xx.c \
  C:\Users\Milad\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.2\Device\Include\LPC17xx.h \
  Source\CMSIS_core\core_cm3.h \
  C:\Users\Milad\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.2\Device\Include\system_LPC17xx.h
